// is a relationship relates to inheritance 
import java.io.*;
  
// Base 
class Car {
  
    private String CarName;
    
    public void setCarName(String CarName)
    {
        this.CarName = CarName;
    }
    public String getCarName()
    {
        return this.CarName + " is a car";
    }
}
// Derived class
class javaisa extends Car {
    public static void main(String gg[])
    {
        Car car = new javaisa();
    
        System.out.println("Car name is Honda");
        car.setCarName("Honda");

        System.out.println(car.getCarName());
    }
}
