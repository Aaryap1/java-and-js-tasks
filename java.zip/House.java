// has-a relationship
public class House {

    // Instance members of class House
    private String houseType;
    private int numberOfRooms;

    public static void main(String[] args) {
        House myHouse = new House();
        myHouse.setHouseType("Villa");
        myHouse.setNumberOfRooms(5);
        myHouse.displayHouseInfo();

        Apartment myApartment = new Apartment();
        myApartment.apartmentInfo();
    }

    // Method to set house type
    public void setHouseType(String houseType) {
        this.houseType = houseType;
    }

    // Method to set number of rooms
    public void setNumberOfRooms(int numberOfRooms) {
        this.numberOfRooms = numberOfRooms;
    }

    // Method to display house information
    public void displayHouseInfo() {
        System.out.println("House Type: " + houseType +
                "\nNumber of Rooms: " + numberOfRooms);
    }
}

class Apartment extends House {

    public void apartmentInfo() {
        Room livingRoom = new Room("Living Room");
        livingRoom.turnOnLights();
        livingRoom.turnOffLights();
    }
}

class Room {

    private String roomName;

    public Room(String roomName) {
        this.roomName = roomName;
    }

    public void turnOnLights() {
        System.out.println(roomName + " lights turned on");
    }

    public void turnOffLights() {
        System.out.println(roomName + " lights turned off");
    }
}
