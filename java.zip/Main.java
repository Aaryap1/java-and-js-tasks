class Laptop {
    public void bootUp() {
        System.out.println("Laptop is booting up...");
    }

    public void shutDown() {
        System.out.println("Laptop is shutting down...");
    }
}

class Person {
    private String name;
    private Laptop laptop; // Person "uses" a Laptop

    public Person(String name, Laptop laptop) {
        this.name = name;
        this.laptop = laptop;
    }

    public void useLaptop() {
        System.out.println(name + " is using the laptop.");
        laptop.bootUp();
        // Perform some tasks with the laptop
        laptop.shutDown();
    }
}

public class Main {
    public static void main(String[] args) {
        Laptop dellLaptop = new Laptop();
        Person alice = new Person("Alice", dellLaptop);
        alice.useLaptop();
    }
}
